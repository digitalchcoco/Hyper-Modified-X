##### Hyper | Magisk Module

##### Contact: https://t.me/AkiraProjects

##### Disclaimer: Naturally, you take all the responsibility for what happens to your device when you start messing around with things. I (Akira) will not be responsible for ANY damage caused to anyone's devices due to the use of this module.

##### Yes, works on all ROMs and on all firmwares.

##### ✓ INSTALLATION: Just flash via Magisk and reboot

#### - ChangeLog -

### Version: X

- Improve Performance For Gaming
- Improve Battery Life
- Touch Improve
- Improve App Opening Speed
- Boost Audio
- Added Force SELinux Permissive
- Improve Ram Management
- Added Powerhint Stable Config 
- Added Touchpaint
- Added DT2W 
- Enable Force Fast Charging
- Added Core Control Parameters
- Added CPU Settings Optimize
- Improve GPU Performance
- Fixed Google Services Drain
- Added CPU Boost
- Added Cpusets Tuning
- Added CAF CPU boost
- CTS Pass
- Added HDR Config
- Added MSM Irqbalance Conf
- Bugs Fixed and improvement
